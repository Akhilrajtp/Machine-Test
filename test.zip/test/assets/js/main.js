

$(document).ready(function() {
  $("<a id='back-to-top' class='icon-up-big' title=''></a>").clone().appendTo("body");
    $("#back-to-top").click(function() {
    $("body,html").animate({
      scrollTop: 0
    }, 800);
    return false;
  }); 
 });
$('.main-nav ul li:has(ul)').addClass('submenu');
$('.main-nav ul li:has(ul)').append("<i></i>");
$('.main-nav ul i').click(function() {
    $(this).parent('li').toggleClass('open');
    $(this).parent('li').children('ul').slideToggle();
})

//Mobile Menu
$('.mob-btn').click(function() {
    if (!$('html').hasClass('show-menu')) {
        $('html').addClass('show-menu');
    } else {
        $('html').removeClass('show-menu');
    }
});

$('.overlay').click(function() {
    if ($('html').hasClass('show-menu')) {
        $('html').removeClass('show-menu');
    }
});
// Slim Header
var header = 0;
function scrollHead() {
  if ($(document).scrollTop() > 10) {
    if (header == 0) {
      header = 1;
      $('html').addClass('slim');
    }
  } else {
    if (header == 1) {
      header = 0;
      $('html').removeClass('slim');
    }
  }
}
scrollHead();

$(window).scroll(scrollHead)
// Back Button
$(window).scroll(function(){
  if($(window).scrollTop() + $(window).height() > $(document).height() - 1500) {
      $('.back-btn').addClass("back-open");
  }else{
      $('.back-btn').removeClass("back-open");
  }
});
$("<a href='javascript:history.go(-1)' class='back-btn icon-right-big' title='back' alt='Back'><span>Back</span></a>").clone().appendTo(".page-back");

// Goto Top of the Page
$(function() {
  $(window).scroll(function() {
    // headerHeight();
    if ($(this).scrollTop() > 150) {
      $("#back-to-top").addClass("visible");
      $('.back-btn').addClass('visible');
    } else {
      $("#back-to-top").removeClass("visible");
      $('.back-btn').removeClass('visible');
    }
  });
  $("#back-to-top").click(function() {
    $("body,html").animate({
      scrollTop: 0
    }, 800);
    return false;
  });
});
